import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class MyFirstChromeTest {
    @Test
    public void startWebDriver() throws InterruptedException {

        ChromeOptions options = new ChromeOptions();
//        if(System.getenv().
//                getOrDefault("BROWSER_STATE","show").
//                equals("Headless")){
//            options.addArguments("--headless");
//        }

        WebDriver driver = new ChromeDriver(options);

        driver.navigate().to("https://testpages.eviltester.com/styled/basic-web-page-test.html");


        //driver.close();
        driver.quit();
    }

    /*

     if https://testpages.herokuapp.com is not working then you can download the
     test pages app from github

     https://github.com/eviltester/TestingApp/tree/master/java/testingapps/seleniumtestpages

     The herokuapp and github release are maintained.

     If you want to learn more about Selenium WebDriver then check out my online courses:

     https://eviltester.com/courses

     */

}