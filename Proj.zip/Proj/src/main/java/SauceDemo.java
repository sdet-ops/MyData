import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.List;

public class SauceDemo {
    public static void main(String[] args){
            System.setProperty("webdriver.gecko.driver", "/Users/Automation/drivers/geckodriver");
            WebDriver driver = new FirefoxDriver();
            driver.get("https://www.saucedemo.com/");
            driver.findElement(By.id("user-name")).sendKeys("standard_user");
            driver.findElement(By.id("password")).sendKeys("secret_sauce");
            driver.findElement(By.id("login-button")).click();
            driver.manage().window().maximize();

//            List<WebElement> price = driver.findElements(By.xpath("//div[@class='inventory_item_price']"));
//
//            for(int i = 0; i< price.size(); i++){
//                float itemPrice = Float.parseFloat(price.get(i).getText().substring(1));
//                if (itemPrice > 20 ){
//                    System.out.println("Item is over 20");
//                }
//            }

            List<WebElement> item = driver.findElements(By.className("inventory_item"));

            for(int i = 1; i<= item.size(); i++){
                if(i == 3) {
                    item.get(i).findElement(By.xpath(".//button[text()='Add to cart']")).click();
                    System.out.println(item.get(i).findElement(By.xpath(".//button[text()='Remove']")).getText().equals("Remove"));
                }
            }
            System.out.println("Test");
    }
}
