public class Casting {
    public static void main(String[] args) {
        ChildClass pt = new ChildClass();
        System.out.println("Name :" + pt.name);
        pt.displayInfo();
    }
}