import java.util.*;

public class TeamRanking {

    public static String rankTeams(String[] votes) {
        int numTeams = votes[0].length();
        Map<Character, int[]> voteMap = new HashMap<>();

        // Initialize voteMap with each team's ranks
        for (char c : votes[0].toCharArray()) {
            voteMap.put(c, new int[numTeams]);
        }

        // Count the votes for each team at each position
        for (String vote : votes) {
            for (int i = 0; i < vote.length(); i++) {
                voteMap.get(vote.charAt(i))[i]++;
            }
        }

        // Convert the map to a list of teams for sorting
        List<Character> teams = new ArrayList<>(voteMap.keySet());

        // Custom comparator to sort teams based on the votes
        Collections.sort(teams, (a, b) -> {
            for (int i = 0; i < numTeams; i++) {
                if (voteMap.get(a)[i] != voteMap.get(b)[i]) {
                    return voteMap.get(b)[i] - voteMap.get(a)[i];
                }
            }
            return a - b;
        });

        // Build the result string
        StringBuilder result = new StringBuilder();
        for (char team : teams) {
            result.append(team);
        }

        return result.toString();
    }

    public static void main(String[] args) {
        String[] votes1 = {"ABC", "ACB", "ABC", "ACB", "ACB"};
        System.out.println(rankTeams(votes1)); // Output: "ACB"

        String[] votes2 = {"WXYZ", "XYZW"};
        System.out.println(rankTeams(votes2)); // Output: "XWYZ"

        String[] votes3 = {"ZMNAGUEDSJYLBOPHRQICWFXTVK"};
        System.out.println(rankTeams(votes3)); // Output: "ZMNAGUEDSJYLBOPHRQICWFXTVK"
    }
}