public class OptionalExample {

}
