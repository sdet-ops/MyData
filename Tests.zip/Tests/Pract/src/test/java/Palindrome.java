public class Palindrome {
    public static void main (String[] args) {
        String original="level", reverse = "";

        int length = original.length();
        for (int i =length-1; i>=0; i--) {
            reverse = reverse + original.charAt(i);
        }
        System.out.println("reverse is:" +reverse);

        if(original.equals(reverse))
            System.out.println("The number is palindrome");
        else
            System.out.println("The number is not a palindrome");

    }
}
