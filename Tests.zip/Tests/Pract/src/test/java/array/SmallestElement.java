package array;

import java.util.Arrays;

public class SmallestElement {
    public static void main(String[] args) {
        int[] arr = {3, 1, 4, 1, 5};
        System.out.println("Smallest: " + Arrays.stream(arr).min().getAsInt());
    }
}
