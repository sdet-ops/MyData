package array;

import java.util.Arrays;

public class SortArray {
    public static void main(String[] args) {
        int[] arr = {3, 1, 4, 1, 5};
        Arrays.sort(arr);
        System.out.println("Sorted: " + Arrays.toString(arr));
    }
}
