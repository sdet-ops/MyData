import java.util.ArrayList;
import java.util.List;

class Test1 {
    static int x = 10;

    static {
        x=x-- - --x;
    }




    public static void main(String args[]) {
        System.out.println(x);
    }
}
