class ParentClass {
    String name="aaa";
    void displayInfo()
    {
        System.out.println("Parent class method");
    }
}