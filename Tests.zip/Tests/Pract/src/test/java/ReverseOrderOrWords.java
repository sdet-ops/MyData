public class ReverseOrderOrWords {
    public static void main(String args[]){
        //reverse sentence
//        String str = "Hello World";
//        String temp = "";
//        String[] strArray = str.split(" ");
//        for(int i= strArray.length-1; i>=0;i--){
//            temp = temp + " "+strArray[i];
//        }
//        System.out.println(temp);

        //reverse words
        String str = "Hello World";
        String reverse = "";
        String[] strArray = str.split(" ");
        for(int i= 0; i < strArray.length;i++){
            for (int j =strArray[i].length()-1; j>=0; j--) {
                reverse = reverse + strArray[i].charAt(j);
            }
            reverse += " ";
        }
        System.out.println(reverse);
    }
}
