public class OddEven {

    public static void main(String[] args) {
        int[] arr = {3, 1, 4, 1, 5};
        System.out.print("Odd: ");
        for (int num : arr) if (num % 2 != 0) System.out.print(num + " ");
        System.out.print("\nEven: ");
        for (int num : arr) if (num % 2 == 0) System.out.print(num + " ");
    }
}