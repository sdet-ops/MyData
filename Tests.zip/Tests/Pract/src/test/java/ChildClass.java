class ChildClass extends ParentClass {
    void displayInfo()
    {
        System.out.println("Child class method");
    }
}
