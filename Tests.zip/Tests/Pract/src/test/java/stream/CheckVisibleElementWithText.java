package stream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class CheckVisibleElementWithText {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();

        try {
            // Navigate to the desired page
            driver.get("https://example.com");
            List<WebElement> elements = driver.findElements(By.xpath("//*[contains(text(), 'Example Domain')]"));

            boolean isVisible = elements.stream()
                    .anyMatch(WebElement::isDisplayed);

            if (isVisible) {
                System.out.println("At least one visible element with the specific text was found.");
            } else {
                System.out.println("No visible elements with the specific text were found.");
            }
        } finally {
            // Quit the driver
            driver.quit();
        }
    }
}
