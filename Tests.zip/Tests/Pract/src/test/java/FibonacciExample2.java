public class FibonacciExample2 {
    int n1=0,n2=1,n3=0;
    void printFibonacci(int count){
        if(count>0){
            n3 = n1 + n2;
            n1 = n2;
            n2 = n3;
            System.out.print(" "+n3);
            printFibonacci(count-1);
        }
    }
    public static void main(String args[]){
        FibonacciExample2 st = new FibonacciExample2();
        int count=10;
        System.out.print(st.n1+" "+st.n2);//printing 0 and 1
        st.printFibonacci(count-2);//n-2 because 2 numbers are already printed
    }
}
