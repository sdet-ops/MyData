package stringManipulation;

public class RemoveTrailingZeros {
    public static void main(String[] args){
        String s = "567700";
        System.out.println(s.replaceFirst("0+$", ""));
    }
}
