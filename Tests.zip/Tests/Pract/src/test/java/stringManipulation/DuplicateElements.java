package stringManipulation;

import java.util.HashSet;

public class DuplicateElements {
    public static void main(String[] args) {
        int[] arr = {1, 2, 2, 3, 4, 4, 5};
        HashSet<Integer> seen = new HashSet<>();
        System.out.println("Duplicates:");
        for (int num : arr) {
            if (!seen.add(num)) { //seen.add(num) will return false if the number num is already present in the HashSet. It returns true only if the number was not already present and was successfully added to the set.
                System.out.println(num);
            }
        }
    }
}
