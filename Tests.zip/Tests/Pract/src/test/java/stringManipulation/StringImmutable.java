package stringManipulation;

public class StringImmutable {
    public static void main(String[] args) {
        String original = "hello";
        System.out.println("Original string: " + original);

        // Attempt to modify the string
        String modified = original.concat(" world");
        System.out.println("After modification: " + modified);

        // Check the original string
        System.out.println("Original string after modification attempt: " + original);
        /*An important point to note here is that, while the String object is immutable, its reference variable is not.
        So that's why, in the above example, the reference was made to refer to a newly formed String object.*/
        //op
     /*   Original string: hello
        After modification: hello world
        Original string after modification attempt: hello*/

//        String str = "Hello";
//        String s = str;
//        str = str.concat(" World");
//        System.out.println(s); // Original String remains unchanged
//        System.out.println(str); // New String created

//        Hello
//        Hello World
    }
}
