package stringManipulation;

import java.util.HashMap;

public class FrequencyCounter {
    public static void main(String[] args) {
        int[] arr = {1, 2, 2, 3, 4, 4, 4};
        HashMap<Integer, Integer> frequency = new HashMap<>();
        for (int num : arr) {
            frequency.put(num, frequency.getOrDefault(num, 0) + 1);
        }

        frequency.forEach((key, value) -> System.out.println(key + ": " + value));
    }
}

/*frequency: This is a HashMap (or similar map) used to store elements (num) as keys and their frequency counts as values.
        frequency.getOrDefault(num, 0):
The getOrDefault method checks if the key num exists in the map.
If num exists, it returns its current value (the frequency count).
If num does not exist, it returns the default value, 0.
        + 1:
The frequency count (either retrieved or defaulted to 0) is incremented by 1 to account for the current occurrence of num.
        frequency.put(num, ...):
This updates the map by assigning the incremented count to the key num.*/
