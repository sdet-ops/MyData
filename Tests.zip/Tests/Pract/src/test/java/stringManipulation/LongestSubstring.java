package stringManipulation;

import java.util.HashSet;

public class LongestSubstring {
        public static void main(String[] args) {
            String s = "abcabcbb";
            int maxLength = 0;
            for (int i = 0; i < s.length(); i++) {
                HashSet<Character> set = new HashSet<>();
                for (int j = i; j < s.length(); j++) {
                    if (!set.add(s.charAt(j))) break;
                    maxLength = Math.max(maxLength, set.size());
                }
                System.out.println(set);
            }
            System.out.println("Longest Length: " + maxLength);

        }
    }


