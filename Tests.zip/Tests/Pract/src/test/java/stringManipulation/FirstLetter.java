package stringManipulation;

public class FirstLetter {

    public static void main(String[] args) {
        String str = "hello world";
        String[] words = str.split("\\s+");
        for (String word : words) {
            System.out.println(word.charAt(0));
        }
    }
}
