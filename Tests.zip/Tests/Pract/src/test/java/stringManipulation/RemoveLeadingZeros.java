package stringManipulation;

public class RemoveLeadingZeros {

    public static void main(String[] args){
        String s = "0005677";
        System.out.println(s.replaceFirst("^0+", ""));
    }
}
