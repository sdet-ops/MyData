package stringManipulation;

public class ReverseString {
    public static void main(String[] args){
        String original = "hello";
        String reverse = "";
//        int length = original.length();
//        for (int i =length-1; i>=0; i--) {
//            reverse = reverse + original.charAt(i);
//        }
//        System.out.println("reverse is:" +reverse);

       // System.out.println(new StringBuilder(original).reverse().toString());
        char ch;
        for (int i = 0; i < original.length(); i++) {

            // extracts each character
            ch = original.charAt(i);

            // adds each character in
            // front of the existing string
            reverse = ch + reverse;
        }

        System.out.println(reverse);
    }
}
