import java.util.HashMap;

public class CharOccurence {
    public static void main(String args[]) {

        String str = "Hello world";
        HashMap<Character,Integer> hMap = new HashMap<>();
        for (int i = 1; i <str.length(); i++) {
            if(hMap.containsKey(str.charAt(i))){
                hMap.put(str.charAt(i), hMap.get(str.charAt(i))+1);
            }else{
                hMap.put(str.charAt(i), 1);
            }
        }
        System.out.println(hMap);
    }
}
