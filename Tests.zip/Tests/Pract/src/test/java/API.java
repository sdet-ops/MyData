import io.restassured.RestAssured;
import org.hamcrest.Matchers;

import java.util.ResourceBundle;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.core.IsEqual.equalTo;

public class API {
    public void GetBookingIds_VerifyStatusCode() {
        RestAssured.baseURI ="https://reqres.in/api/user?=2";

        // Given
        given()
                // When
                .when()
                .get()
                // Then
                .then()
                .statusCode(200)
                .statusLine("HTTP/1.1 200 OK")
                // To verify booking id at index 3
                .body("size()", Matchers.lessThanOrEqualTo(6));


    }
    public static void main(String args[]){
        API api = new API();
        api.GetBookingIds_VerifyStatusCode();
    }
}
