import java.util.function.Consumer;
import java.util.function.Predicate;

public class TestLambda {
    public static void main(String[] args){
        Predicate<String> lengthOIfStr = s -> s.length() > 5;
//        boolean result = lengthOIfStr.test("abcds6");
//        System.out.println(result);
        doSomething(lengthOIfStr);
        Consumer<String> print = p-> System.out.println(p.toUpperCase());
        print.accept("Consumer fI");
    }

    public static void doSomething(Predicate<String> p){
        System.out.println("Predicate test....."+ p.test("eretrte"));
    }
}
