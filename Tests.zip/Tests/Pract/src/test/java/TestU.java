import java.util.*;

public class TestU {

    public static List<List<Integer>> matchSentences(List<String> sentences, List<String> queries) {
        List<Set<String>> sentenceWordSets = new ArrayList<>();

        // Convert each sentence into a set of words
        for (String sentence : sentences) {
            Set<String> wordSet = new HashSet<>(Arrays.asList(sentence.split("\\s+")));
            sentenceWordSets.add(wordSet);
        }

        List<List<Integer>> results = new ArrayList<>();

        // Process each query
        for (String query : queries) {
            String[] queryWords = query.split("\\s+");
            List<Integer> matchedIndices = new ArrayList<>();

            for (int i = 0; i < sentenceWordSets.size(); i++) {
                Set<String> wordSet = sentenceWordSets.get(i);
                boolean allMatch = true;

                for (String word : queryWords) {
                    if (!wordSet.contains(word)) {
                        allMatch = false;
                        break;
                    }
                }

                if (allMatch) {
                    matchedIndices.add(i);
                }
            }

            if (matchedIndices.isEmpty()) {
                matchedIndices.add(-1);
            }

            results.add(matchedIndices);
        }

        return results;
    }

    public static void main(String[] args) {
        List<String> sentences = Arrays.asList(
                "bob and alice like to text each other",
                "bob does not like to ski but does not like to fall",
                "Alice likes to ski"
        );
        List<String> queries = Arrays.asList("bob alice", "alice", "like", "non occurrence");

        List<List<Integer>> results = matchSentences(sentences, queries);

        for (List<Integer> result : results) {
            System.out.println(result);
        }
    }
}
